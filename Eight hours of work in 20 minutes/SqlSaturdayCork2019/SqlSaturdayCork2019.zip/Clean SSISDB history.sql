use ssisdb;

exec dbo.CleanHistory 1;

