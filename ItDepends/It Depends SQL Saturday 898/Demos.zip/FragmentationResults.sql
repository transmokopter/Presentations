USE PerformanceResults
GO 
--SELECT * FROM performanceresults.dbo.spinningraw;
SELECT * FROM performanceresults.dbo.spinningavg;
--SELECT * FROM performanceresults.dbo.ssdraw;
SELECT * FROM performanceresults.dbo.ssdavg;
