CREATE TABLE [dbo].[AdventureWorksDWBuildVersion] (
    [DBVersion]   VARCHAR (50) NULL,
    [VersionDate] datetime2(6)      NULL
);
GO

